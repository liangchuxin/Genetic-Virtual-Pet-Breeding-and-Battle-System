// Game main class header
