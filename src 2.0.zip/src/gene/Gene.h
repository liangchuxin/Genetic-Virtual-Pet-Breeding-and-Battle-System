// Gene base class header
