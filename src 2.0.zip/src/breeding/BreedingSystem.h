// Breeding system header
