#include <iostream>
using namespace std;

#include "battle/BattleEngine.h"

int main() {
    srand(static_cast<unsigned int>(time(0)));
    cout << "Genetic Virtual Pet System" << endl;
    Battle battle;
    battle.start();
    return 0;
}
